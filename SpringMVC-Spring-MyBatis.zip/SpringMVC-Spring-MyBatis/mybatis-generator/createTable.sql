create table muser(
id varchar2(36) primary key,
name varchar2(36),
age number(8),
address varchar2(36)
);